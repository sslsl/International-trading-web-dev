
django.jQuery(function($) {
	'use strict';

	django.cascade.ProcessNextStepPlugin = ring.create(eval(django.cascade.ring_plugin_bases.ProcessNextStepPlugin), {});
});
